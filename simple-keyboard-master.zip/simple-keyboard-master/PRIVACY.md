We don't store your data. Period.
